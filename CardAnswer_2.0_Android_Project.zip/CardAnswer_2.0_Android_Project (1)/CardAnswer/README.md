# CardAnswer 2.0 — Android source project

영어 퀴즈가 표시된 화면을 사용자가 허용한 MediaProjection으로 캡처하고, OCR로 문제 변경을 감지한 뒤 Gemini API에 화면 이미지와 인식 텍스트를 보내 답을 오버레이로 표시하는 초기 구현입니다.

## 지원 범위
- 객관식: 선택지 번호/문자와 정답 문구 표시
- 서술형·단답형·빈칸·어휘·문법·번역 문제
- 한국어 설명을 포함한 답안 제시
- 약 1.4초 간격 화면 확인, 인식 텍스트가 바뀌면 새 문제 분석
- 다른 앱 위에 답변 오버레이 표시

## 빌드
1. Android Studio에서 프로젝트 폴더를 엽니다.
2. JDK 17과 Android SDK 35를 준비합니다.
3. Gradle Sync 후 `Build > Build Bundle(s) / APK(s) > Build APK(s)`를 실행합니다.
4. APK는 `app/build/outputs/apk/debug/app-debug.apk`에 생성됩니다.

## 사용
1. Google AI Studio에서 Gemini API 키를 발급합니다.
2. 앱에 키를 입력하고 자동 인식 시작을 누릅니다.
3. 다른 앱 위에 표시 권한을 허용합니다.
4. Android 시스템 화면 캡처 권한을 허용합니다.
5. 영어 문제가 표시된 앱으로 이동하면 상단 오버레이에 분석 결과가 나타납니다.
6. 중지하려면 CardAnswer 앱에서 인식 중지를 누릅니다.

## 중요 사항
- 이 ZIP은 **APK가 아니라 Android Studio용 소스 프로젝트**입니다. 이 환경에서 실제 기기용 APK 빌드와 태블릿 실기기 테스트는 수행하지 않았습니다.
- Gemini API 사용에는 인터넷과 API 키가 필요합니다. 사용량에 따라 비용이 발생할 수 있습니다. Google AI Studio의 현재 요금과 한도를 확인하세요.
- API 키는 APK에 하드코딩하지 않고 앱 설정에 입력해 로컬 SharedPreferences에 저장합니다. 다만 루팅된 기기나 악성 앱/백업 환경에서는 추출 위험이 있으므로 개인 테스트용으로만 사용하고 키 사용량 제한을 설정하세요. 상용 배포라면 별도 백엔드 프록시를 권장합니다.
- 화면은 Android 시스템 동의 후 캡처되며, 캡처 이미지와 OCR 텍스트는 Gemini API로 전송됩니다. 개인정보나 민감한 화면에서 실행하지 마세요.
- 자동 감지는 OCR 텍스트 변화에 의존하므로 이미지형 문제, 글자가 작은 화면, 비슷한 연속 문제 등에서 놓치거나 중복 감지할 수 있습니다. 정답 정확도를 보장하지 않습니다.
- Android 14 이상에서는 MediaProjection 세션마다 사용자 동의가 필요합니다. 앱은 사용자가 시작한 현재 세션만 캡처합니다.
- API 모델 이름은 `CaptureService.kt`의 `MODEL` 상수에서 바꿀 수 있습니다.
