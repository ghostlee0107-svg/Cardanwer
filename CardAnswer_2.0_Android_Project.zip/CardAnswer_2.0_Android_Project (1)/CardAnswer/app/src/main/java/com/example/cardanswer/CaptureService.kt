
package com.example.cardanswer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.provider.Settings
import android.util.Base64
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "result_data"

        private const val CHANNEL = "cardanswer_capture"
        private const val MODEL = "gemini-3.8-flash"
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: TextView? = null
    private var windowManager: WindowManager? = null
    private var worker: Handler? = null

    private val busy = AtomicBoolean(false)

    private val recognizer =
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private val http = OkHttpClient.Builder()
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    private var lastQuestion = ""
    private var apiKey = ""

    override fun onCreate() {
        super.onCreate()

        val thread = HandlerThread("CardAnswerCapture").apply {
            start()
        }

        worker = Handler(thread.looper)

        createNotificationChannel()

        val notification = notification()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                7,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(7, notification)
        }

        if (Settings.canDrawOverlays(this)) {
            createOverlay()
        }

        apiKey = getSharedPreferences(
            "cardanswer",
            MODE_PRIVATE
        ).getString("gemini_key", "").orEmpty()
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {

        val resultCode =
            intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0

        @Suppress("DEPRECATION")
        val data =
            if (Build.VERSION.SDK_INT >= 33) {
                intent?.getParcelableExtra(
                    EXTRA_DATA,
                    Intent::class.java
                )
            } else {
                intent?.getParcelableExtra(EXTRA_DATA)
            }

        if (data == null || apiKey.isBlank()) {
            stopSelf()
            return START_NOT_STICKY
        }

        val manager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE)
                    as MediaProjectionManager

        projection = manager.getMediaProjection(resultCode, data)

        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels

        reader = ImageReader.newInstance(
            width,
            height,
            PixelFormat.RGBA_8888,
            3
        )

        projection?.registerCallback(
            object : MediaProjection.Callback() {
                override fun onStop() {
                    stopSelf()
                }
            },
            worker
        )

        virtualDisplay = projection?.createVirtualDisplay(
            "CardAnswerDisplay",
            width,
            height,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface,
            null,
            worker
        )

        worker?.post(captureLoop)

        return START_NOT_STICKY
    }

    private val captureLoop = object : Runnable {

        override fun run() {

            val image = reader?.acquireLatestImage()

            if (image != null && busy.compareAndSet(false, true)) {

                val bitmap = imageToBitmap(image)
                image.close()

                if (bitmap != null) {

                    val input = InputImage.fromBitmap(bitmap, 0)

                    recognizer.process(input)
                        .addOnSuccessListener { result ->

                            val questionText = result.textBlocks
                                .flatMap { it.lines }
                                .map { it.text.trim() }
                                .filter { line ->

                                    val lower = line.lowercase()

                                    line.isNotBlank() &&
                                            !lower.startsWith("cardanswer") &&
                                            !line.startsWith("문제:") &&
                                            !line.startsWith("정답:") &&
                                            !line.startsWith("설명:") &&
                                            !line.startsWith("문제 분석 결과")
                                }
                                .joinToString("\n")

                            if (
                                looksLikeQuestion(questionText) &&
                                questionText != lastQuestion
                            ) {

                                lastQuestion = questionText

                                showStatus("문제 감지됨 · 답을 분석하는 중…")

                                askGemini(bitmap, questionText)

                            } else {
                                busy.set(false)
                            }
                        }
                        .addOnFailureListener {
                            busy.set(false)
                        }
                        .addOnCompleteListener {
                            bitmap.recycle()
                        }

                } else {
                    busy.set(false)
                }

            } else {
                image?.close()
            }

            worker?.postDelayed(this, 1400)
        }
    }

    private fun looksLikeQuestion(text: String): Boolean {

        val cleaned = text
            .replace("\\s".toRegex(), " ")
            .trim()

        return cleaned.length >= 12 &&
                cleaned.any { it.isLetter() }
    }

    private fun imageToBitmap(image: Image): Bitmap? {

        return try {

            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride

            val rowPadding =
                rowStride - pixelStride * image.width

            val padded = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride,
                image.height,
                Bitmap.Config.ARGB_8888
            )

            buffer.rewind()
            padded.copyPixelsFromBuffer(buffer)

            val cropped = Bitmap.createBitmap(
                padded,
                0,
                0,
                image.width,
                image.height
            )

            padded.recycle()

            cropped

        } catch (_: Exception) {
            null
        }
    }

    private fun askGemini(
        bitmap: Bitmap,
        recognizedText: String
    ) {

        val output = ByteArrayOutputStream()

        bitmap.compress(
            Bitmap.CompressFormat.JPEG,
            72,
            output
        )

        val encoded = Base64.encodeToString(
            output.toByteArray(),
            Base64.NO_WRAP
        )

        val prompt = """
You are CardAnswer, an English quiz assistant.
Read the attached screenshot and solve the active English question.

Recognized screen text (may contain OCR errors):
$recognizedText

Handle:
- Multiple-choice questions
- Fill-in-the-blank questions
- Grammar questions
- Vocabulary questions
- Translation questions
- Short-answer questions
- Open-ended written questions

Ignore app buttons, timers, navigation labels,
previous questions, and unrelated instructions.

Return concise Korean output in this exact structure:

문제: (briefly restate the active question)
정답: (the best answer; for multiple choice include option number/letter and answer text)
설명: (one or two short sentences explaining why)

If the screenshot does not contain a readable active question,
return:
문제를 정확히 읽지 못했어요. 화면을 조금 확대해 주세요.

Do not guess when the question or choices are unreadable.
""".trimIndent()

        val input = JSONArray()
            .put(
                JSONObject()
                    .put("type", "text")
                    .put("text", prompt)
            )
            .put(
                JSONObject()
                    .put("type", "image")
                    .put("data", encoded)
                    .put("mime_type", "image/jpeg")
            )

        val body = JSONObject()
            .put("model", MODEL)
            .put("input", input)

        val request = Request.Builder()
            .url(
                "https://generativelanguage.googleapis.com/v1beta/interactions"
            )
            .addHeader("x-goog-api-key", apiKey)
            .addHeader("Content-Type", "application/json")
            .post(
                body.toString().toRequestBody(
                    "application/json; charset=utf-8".toMediaType()
                )
            )
            .build()

        http.newCall(request).enqueue(object : Callback {

            override fun onFailure(
                call: Call,
                e: IOException
            ) {

                worker?.post {
                    showAnswer(
                        "연결 오류",
                        "인터넷 연결과 Gemini API 키를 확인해 주세요."
                    )
                }

                busy.set(false)
            }

            override fun onResponse(
                call: Call,
                response: Response
            ) {

                response.use {

                    val raw = it.body?.string().orEmpty()

                    val answer = try {

                        val root = JSONObject(raw)

                        if (!it.isSuccessful) {

                            root.optJSONObject("error")
                                ?.optString("message")
                                ?.takeIf { message -> message.isNotBlank() }
                                ?: "Gemini API 오류가 발생했어요. (${it.code})"

                        } else {

                            val result = StringBuilder()

                            // Interactions API response
                            // can contain model_output steps.

                            val steps = root.optJSONArray("steps")

                            if (steps != null) {

                                for (i in 0 until steps.length()) {

                                    val step =
                                        steps.optJSONObject(i) ?: continue

                                    if (
                                        step.optString("type") != "model_output"
                                    ) {
                                        continue
                                    }

                                    val content =
                                        step.optJSONArray("content")
                                            ?: continue

                                    for (j in 0 until content.length()) {

                                        val item =
                                            content.optJSONObject(j)
                                                ?: continue

                                        if (
                                            item.optString("type") == "text"
                                        ) {
                                            result.append(
                                                item.optString("text")
                                            )
                                        }
                                    }
                                }
                            }

                            // Fallback if output_text is returned.
                            if (result.isEmpty()) {
                                result.append(
                                    root.optString("output_text")
                                )
                            }

                            result.toString().trim().ifBlank {
                                "답변을 가져오지 못했어요. 다시 시도해 주세요."
                            }
                        }

                    } catch (_: Exception) {

                        "답변을 읽지 못했어요. API 응답을 확인해 주세요."
                    }

                    worker?.post {
                        showAnswer("문제 분석 결과", answer)
                    }
                }

                busy.set(false)
            }
        })
    }

    private fun createOverlay() {

        windowManager =
            getSystemService(WINDOW_SERVICE) as WindowManager

        overlay = TextView(this).apply {

            text = "CardAnswer 2.0\n화면을 확인하고 있어요."
            textSize = 14f

            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xEE20243A.toInt())

            setPadding(22, 16, 22, 16)
        }

        val type =
            if (Build.VERSION.SDK_INT >= 26) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {

            gravity = Gravity.TOP
            y = 28
        }

        try {
            windowManager?.addView(overlay, params)
        } catch (_: Exception) {
        }
    }

    private fun showStatus(message: String) {

        overlay?.post {
            overlay?.text =
                "CardAnswer 2.0\n$message"
        }
    }

    private fun showAnswer(
        title: String,
        answer: String
    ) {

        overlay?.post {
            overlay?.text =
                "CardAnswer 2.0 · $title\n$answer"
        }
    }

    private fun createNotificationChannel() {

        if (Build.VERSION.SDK_INT >= 26) {

            val channel = NotificationChannel(
                CHANNEL,
                "CardAnswer 화면 인식",
                NotificationManager.IMPORTANCE_LOW
            )

            getSystemService(
                NotificationManager::class.java
            ).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {

        val builder =
            if (Build.VERSION.SDK_INT >= 26) {
                Notification.Builder(this, CHANNEL)
            } else {
                Notification.Builder(this)
            }

        return builder
            .setContentTitle("CardAnswer 2.0 실행 중")
            .setContentText(
                "화면의 영어 문제를 자동으로 분석하고 있습니다."
            )
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .build()
    }

    override fun onDestroy() {

        worker?.removeCallbacksAndMessages(null)

        virtualDisplay?.release()
        reader?.close()
        projection?.stop()

        try {
            overlay?.let {
                windowManager?.removeView(it)
            }
        } catch (_: Exception) {
        }

        recognizer.close()
        http.dispatcher.cancelAll()

        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
}
