package com.example.cardanswer

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val captureRequest = 4102
    private lateinit var apiKeyInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cardanswer", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 28)
        }
        val title = TextView(this).apply {
            text = "CardAnswer 2.0"
            textSize = 28f
            setTextColor(0xFF20243A.toInt())
        }
        val description = TextView(this).apply {
            text = "화면의 영어 문제를 자동으로 읽고 답을 제시합니다.\n객관식 · 빈칸 · 문법 · 번역 · 서술형 지원\n\nGemini API 키를 입력한 뒤 자동 인식을 시작하세요."
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 18)
        }
        apiKeyInput = EditText(this).apply {
            hint = "Gemini API Key"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            singleLine = true
            setText(prefs.getString("gemini_key", ""))
        }
        val keyNote = TextView(this).apply {
            text = "API 키는 이 기기에만 저장됩니다. APK에 키를 포함하지 마세요."
            textSize = 12f
            setTextColor(0xFF666666.toInt())
            setPadding(0, 4, 0, 18)
        }
        val start = Button(this).apply {
            text = "자동 인식 시작"
            setOnClickListener {
                val key = apiKeyInput.text.toString().trim()
                if (key.isBlank()) {
                    Toast.makeText(this@MainActivity, "Gemini API 키를 먼저 입력해 주세요.", Toast.LENGTH_LONG).show()
                } else {
                    prefs.edit().putString("gemini_key", key).apply()
                    beginCapture()
                }
            }
        }
        val stop = Button(this).apply {
            text = "인식 중지"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                Toast.makeText(this@MainActivity, "CardAnswer를 중지했습니다.", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(title)
        root.addView(description)
        root.addView(apiKeyInput)
        root.addView(keyNote)
        root.addView(start)
        root.addView(stop)
        setContentView(root)
    }

    private fun beginCapture() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "다른 앱 위에 표시 권한을 허용한 뒤 다시 시작해 주세요.", Toast.LENGTH_LONG).show()
            return
        }
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
    }

    @Deprecated("Deprecated by platform; retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_DATA, data)
            }
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
        }
    }
}
