package com.example.cardanswer

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.concurrent.thread

object Translator {
    // Uses MyMemory's public translation endpoint. Network access is required.
    fun translate(raw: String, callback: (String) -> Unit) {
        val text = raw.trim().replace(Regex("\\s+"), " ")
        val hasKorean = text.any { it in '\uAC00'..'\uD7A3' }
        val pair = if (hasKorean) "ko|en" else "en|ko"
        thread {
            var answer = "뜻을 찾지 못했어요"
            try {
                val encoded = URLEncoder.encode(text, "UTF-8")
                val connection = (URL("https://api.mymemory.translated.net/get?q=$encoded&langpair=$pair")
                    .openConnection() as HttpURLConnection).apply {
                    connectTimeout = 5000
                    readTimeout = 5000
                    requestMethod = "GET"
                }
                val body = connection.inputStream.bufferedReader().use { it.readText() }
                val translated = JSONObject(body).optJSONObject("responseData")
                    ?.optString("translatedText").orEmpty()
                if (translated.isNotBlank()) answer = translated
                connection.disconnect()
            } catch (_: Exception) {}
            Handler(Looper.getMainLooper()).post { callback(answer) }
        }
    }
}
